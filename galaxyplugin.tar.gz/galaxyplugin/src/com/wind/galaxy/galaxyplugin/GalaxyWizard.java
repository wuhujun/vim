package com.wind.galaxy.galaxyplugin;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.dialogs.WizardNewProjectCreationPage;

public class GalaxyWizard extends Wizard implements INewWizard {

    private WizardNewProjectCreationPage page;

    /**
     *  
     */
    public GalaxyWizard() {
        super();
    }

    public void addPages() {
        page = new WizardNewProjectCreationPage("page1");
        page.setDescription("Galaxy 是由techX02部门开发的一款大数据分析平台，");
        page.setTitle("创建一个新的galaxy项目");
        addPage(page);
    }

    public boolean performFinish() {
        boolean result = false;

        System.out.println("project page.name = " + page.getProjectName());
        System.out.println("project page.path = " + page.getLocationPath());
        IProject project = page.getProjectHandle();
        try {
            project.create(null);
            result = true;
        } catch (CoreException e) {
            e.printStackTrace();
        }

        IProjectDescription projectDesc = null;
        try {
            project.open(null);
            projectDesc = project.getDescription();
        } catch (CoreException e1) {
            e1.printStackTrace();
        }

        String[] natureIds = projectDesc.getNatureIds();
        String[] newNatureIds = new String[natureIds.length + 1];
        System.arraycopy(natureIds, 0, newNatureIds, 0, natureIds.length);
        newNatureIds[natureIds.length] = "com.wind.galaxy.galaxyplugin.GalaxyNature";
        projectDesc.setNatureIds(newNatureIds);
        try {
            project.setDescription(projectDesc, null);
        } catch (CoreException e2) {
            e2.printStackTrace();
        }

        return result;
    }

    public void init(IWorkbench workbench, IStructuredSelection selection) {

    }

}