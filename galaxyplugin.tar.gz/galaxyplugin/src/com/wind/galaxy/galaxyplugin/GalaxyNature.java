package com.wind.galaxy.galaxyplugin ;

import org.eclipse.core.resources.ICommand;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IProjectNature;
import org.eclipse.core.runtime.CoreException;



public class GalaxyNature implements IProjectNature {

    private IProject _project;

    public void configure() throws CoreException {
    	System.out.println("configure");
        IProjectDescription projectDesc = _project.getDescription();
        ICommand[] buildSpec = projectDesc.getBuildSpec();
        boolean hasBuilder = false;

        for (int i = 0; i < buildSpec.length; ++i) {
            if (buildSpec[i]
                .getBuilderName()
                .equals("com.wind.galaxy.galaxyplugin.GalaxyBuilder")) {
                hasBuilder = true;
                System.out.println("true");
                break;
            }
        }

        if (hasBuilder == false) {
        	System.out.println("false");
            ICommand newCommand = projectDesc.newCommand();
            newCommand.setBuilderName("com.wind.galaxy.galaxyplugin.GalaxyBuilder");
            ICommand[] buildSpecs = new ICommand[buildSpec.length + 1];

            System.arraycopy(buildSpec, 0, buildSpecs, 1, buildSpec.length);
            buildSpecs[0] = newCommand;
            projectDesc.setBuildSpec(buildSpecs);
            _project.setDescription(projectDesc, null);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.core.resources.IProjectNature#deconfigure()
     */
    public void deconfigure() throws CoreException {
        // TODO Auto-generated method stub

    }

    
    public IProject getProject() {
    	System.out.println("getProject");
        // TODO Auto-generated method stub
        return _project;
    }

    
    public void setProject(IProject project) {
    	System.out.println("setProject");
        // TODO Auto-generated method stub
        _project = project;
    }

}