package com.wind.galaxy.galaxyplugin;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;




public class WorkbenchPreferencePage extends PreferencePage implements
        IWorkbenchPreferencePage {

    private Text _greeting;

    /**
     *  
     */
    public WorkbenchPreferencePage() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @param title
     */
    public WorkbenchPreferencePage(String title) {
        super(title);
        // TODO Auto-generated constructor stub
    }

    /**
     * @param title
     * @param image
     */
    public WorkbenchPreferencePage(String title, ImageDescriptor image) {
        super(title, image);
        // TODO Auto-generated constructor stub
    }

    protected Control createContents(Composite parent) {
        Label label = new Label(parent, SWT.CENTER);
        label.setText("Greeting");
        _greeting = new Text(parent, SWT.SINGLE | SWT.BORDER);

        return parent;
    }

    protected IPreferenceStore doGetPreferenceStore() {
        System.out.println("WorkbenchPreferencePage.doGetPreferenceStore()");
        return GalaxyPlugin.getDefault().getPreferenceStore();
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.IWorkbenchPreferencePage#init(org.eclipse.ui.IWorkbench)
     */
    public void init(IWorkbench workbench) {
        // TODO Auto-generated method stub

    }

    @SuppressWarnings("deprecation")
	protected void performDefaults() {
        System.out.println("WorkbenchPreferencePage.performDefaults()");
        IPreferenceStore prefStore = getPreferenceStore();
        prefStore.setValue(GalaxyPlugin.GREETING, "world");
        GalaxyPlugin.getDefault().savePluginPreferences();

        _greeting.setText(prefStore.getString(GalaxyPlugin.GREETING));
    }

    @SuppressWarnings("deprecation")
	public boolean performOk() {
        boolean result = false;

        System.out.println("WorkbenchPreferencePage.performOk()");
        IPreferenceStore prefStore = getPreferenceStore();
        prefStore.setValue(GalaxyPlugin.GREETING, _greeting.getText());
        GalaxyPlugin.getDefault().savePluginPreferences();

        result = true;

        return result;
    }
}